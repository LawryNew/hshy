mongod --slave --source 192.168.0.217:27017 --config=/data/mongodb/run/mongod_27018.conf --dbpath=/data/mongodb/data_27018/  --logpath=/data/mongodb/logs/mongo_27018.log &
mongod --slave --source 192.168.0.120:27017 --config=/data/mongodb/run/mongod_27017.conf --dbpath=/data/mongodb/data_27017/  --logpath=/data/mongodb/logs/mongo_27017.log &
