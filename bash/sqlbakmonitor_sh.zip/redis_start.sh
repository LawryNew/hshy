nohup redis-server /usr/local/redis/etc/game_redis_6379.conf &
nohup redis-server /usr/local/redis/etc/php_redis_6389.conf &
