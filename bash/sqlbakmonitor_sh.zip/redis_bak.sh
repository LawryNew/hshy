#!/bin/bash

back_dir=/data/redis_backup
now_day=$(date +%Y-%m-%d)
now_time=$(date +%Y-%m-%d-%H)

backup_dir=${back_dir}/${now_day}
game_redis_dir=/usr/local/redis/data_6379
qmd_redis_dir=/usr/local/redis/data_6389

#创建备份文件夹
if [ ! -d "${backup_dir}" ]; then
    mkdir -p  "${backup_dir}"
fi


game_save=`/usr/local/redis/bin/redis-cli -p 6379 -a hxhmpasswordqiezi save`
qmd_save=`/usr/local/redis/bin/redis-cli -p 6389 -a qiezi save`

cd ${game_redis_dir} && zip -r ${backup_dir}/game_${now_time}.zip ./dump*.rdb
cd ${qmd_redis_dir} && zip -r ${backup_dir}/qmd_${now_time}.zip ./dump*.rdb

find ${back_dir} -mtime +30 -type f -name "*" -exec rm -rf {} \;
