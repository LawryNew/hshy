#!/bin/bash

 nohup /usr/local/mysql/bin/mysqld_safe --defaults-file=/etc/my_3306.cnf &
 nohup /usr/local/mysql/bin/mysqld_safe --defaults-file=/etc/my_3307.cnf &
 nohup /usr/local/mysql/bin/mysqld_safe --defaults-file=/etc/my_3308.cnf &

