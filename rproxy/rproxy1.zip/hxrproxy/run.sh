now=`date +"%Y%m%d"`
nohup ./rproxy -local 0.0.0.0:0 -upstream 47.107.182.186:50002 -bind 0.0.0.0:8002 > ${now}-rproxy.log &
