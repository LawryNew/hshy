#nohup ./tebot  -debug -token "bot863640781:AAHt9ZpT3lvQ7lAljWuf1x2n2V0fAn3_eDw" -bind "0.0.0.0:49999" &

nohup ./tebot  -debug -token "1084629543:AAEhDReCr155QjGjB1ddJ2LvkwLbgTiN4Lg" -bind "0.0.0.0:29933" &
