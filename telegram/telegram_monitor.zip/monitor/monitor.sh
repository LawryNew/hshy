#!/bin/bash

disk=`df -lh|grep "/dev/nv" |awk '{print $5}'|cut -d % -f1`
#获取磁盘占用
load=`uptime|awk '{print $11}'|cut -d. -f1`
#5min 负载


for i in $disk;
do
	 [ $i -gt 60 ] && curl http://192.168.0.58:29934 -H 'command:notify' -d "磁盘占用大于60，请检查！！！";
done

for j in $load;
do
	[ $j -gt 3 ] && curl http://192.168.0.58:29934 -H 'command:notify' -d "系统负载大于3，请检查！！！！";
done



