1.解压tebot 替换start.sh 中的机器人token 并启动

2.唤醒机器人，测试Telegram是否收到消息
 curl http://ip(启动tebot程序的serverip):29934 -H 'command:notify' -d "test";

3.修改monitor.sh  ip为 serverip  加入crontab